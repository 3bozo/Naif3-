import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App" style={{ fontFamily: 'Arial', backgroundColor: 'white', padding: '20px' }}>
      <header style={{ textAlign: 'center', marginBottom: '40px' }}>
        <img src="/images/logo.png" alt="Naif Flower Store" style={{ maxWidth: '200px' }} />
        <h1>Welcome to Naif Flower Store</h1>
        <p>Your favorite place for beautiful and fresh flowers!</p>
      </header>
      <section style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: '20px' }}>
        <div style={{ border: '1px solid #eee', padding: '10px', borderRadius: '8px' }}>
          <img src="/images/flower1.jpg" alt="Flower 1" style={{ width: '100%', borderRadius: '8px' }} />
          <h3>Red Roses</h3>
          <p>Elegant bouquet of red roses, perfect for romantic occasions.</p>
        </div>
        <div style={{ border: '1px solid #eee', padding: '10px', borderRadius: '8px' }}>
          <img src="/images/flower2.jpg" alt="Flower 2" style={{ width: '100%', borderRadius: '8px' }} />
          <h3>Mixed Flowers</h3>
          <p>Colorful mix of seasonal flowers to brighten any room.</p>
        </div>
      </section>
    </div>
  );
}

export default App;
